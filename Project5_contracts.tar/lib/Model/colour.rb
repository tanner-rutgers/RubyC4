module Model
  module Colour

    RED = :red
    BLUE = :blue
    BLACK = :black
    WHITE = :white
    GREEN = :green
    PINK = :pink

  end
end
module Model
  module Observer
    def notify
      raise "Not implememented Error"    
    end
  end
end

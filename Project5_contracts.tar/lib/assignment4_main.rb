require_relative 'RubyC4Application.rb'

RubyC4Application.new

require 'test/unit'
require_relative 'ui_observer.rb'

module View
	class UiGameList
		include UiObserver
		include Test::Unit::Assertions

		def initialize

		end

		def update

		end

	end
end
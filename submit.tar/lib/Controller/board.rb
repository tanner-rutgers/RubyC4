require_relative 'observable.rb'

class Board
	include Observable
  
end
require_relative 'observable.rb'

class Menu
	include Observable

end
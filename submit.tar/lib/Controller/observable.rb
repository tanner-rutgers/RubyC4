module Observable

  def self.addObserver

  end

  def self.notify

  end

end
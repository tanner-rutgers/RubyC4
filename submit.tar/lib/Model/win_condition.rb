module Model

  class WinCondition
    include Test::Unit::TestCase

    def initialize(pattern)
      assert(patter.is_a?Array)

      assert_equal(@pattern, pattern)
    end

    def hasWon?(board)

    end
  end
end
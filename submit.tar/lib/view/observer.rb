require 'test/unit'

module Observer

	def self.update

  end

end